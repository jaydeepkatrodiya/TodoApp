package com.example.todoapp

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.todoapp.databinding.ActivityUpdateNoteBinding

class UpdateNoteActivity : AppCompatActivity() {
    private lateinit var binding: ActivityUpdateNoteBinding
    private lateinit var db: NotesDatabaseHelper
    private var noteId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUpdateNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = NotesDatabaseHelper(this)

        noteId = intent.getIntExtra("note_id", -1)
        if (noteId == -1) {
            finish()
            return
        }

        val note = db.getNoteById(noteId)
        binding.titleuEditText.setText(note.title)
        binding.edtUDescription.setText(note.description)


        val genderOptions = resources.getStringArray(R.array.Task_Type)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, genderOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.genderuSpinner.adapter = adapter

        val genderPosition = genderOptions.indexOf(note.task)
        if (genderPosition >= 0) {
            binding.genderuSpinner.setSelection(genderPosition)
        }

        binding.updatesaveButton.setOnClickListener {
            val newTitle = binding.titleuEditText.text.toString()
            val newdescription = binding.edtUDescription.text.toString()
            val newtask = binding.genderuSpinner.selectedItem.toString()

            if (newTitle.isEmpty()) {
                Toast.makeText(this, "Please fill Name", Toast.LENGTH_SHORT).show()

            }

            else if (newdescription.isEmpty()) {
                Toast.makeText(this, "Please enter Description", Toast.LENGTH_SHORT).show()
            }

            else if (newtask == "Task") {

                Toast.makeText(this, "Please Select Task Type", Toast.LENGTH_SHORT).show()
            }


            else {
                val updateNote = Note(noteId, newTitle, newdescription,newtask)
                db.updateNote(updateNote)
                Toast.makeText(this, "Data Updated", Toast.LENGTH_SHORT).show()
                finish()
            }

        }
    }
}
