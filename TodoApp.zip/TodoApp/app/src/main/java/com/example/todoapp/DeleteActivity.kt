package com.example.todoapp

import android.app.AlertDialog
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class DeleteActivity : AppCompatActivity() {
    lateinit var deleteButton:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_delete)

        deleteButton = findViewById(R.id.deleteButton)


        fun showDeleteDialog(context: Context, id: Int, dbHelper: NotesDatabaseHelper, onDeleteSuccess: () -> Unit) {
            val builder = AlertDialog.Builder(context)
            builder.setTitle("Delete Item")
            builder.setMessage("Are you sure you want to delete this item?")
            builder.setPositiveButton("Yes") { dialog, _ ->
                dbHelper.deleteNote(id)
                onDeleteSuccess()
                dialog.dismiss()
            }
            builder.setNegativeButton("No") { dialog, _ ->
                dialog.dismiss()
            }
            builder.create().show()
        }

    }
}