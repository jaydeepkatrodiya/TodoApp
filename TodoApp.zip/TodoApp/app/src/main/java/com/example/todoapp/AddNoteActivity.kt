package com.example.todoapp

import android.R
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import com.example.todoapp.databinding.ActivityAddNoteBinding

class AddNoteActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddNoteBinding
    private lateinit var db: NotesDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = NotesDatabaseHelper(this)


        val taskOption = arrayOf("Select Task Type", "High", "Medium","Law")
        val adapter = ArrayAdapter(this, R.layout.simple_spinner_item, taskOption)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.genderSpinner.adapter = adapter

        binding.saveButton.setOnClickListener {
            val title = binding.titleEditText.text.toString()
            val description = binding.edtDescription.text.toString()
            val task = binding.genderSpinner.selectedItem.toString()


            if (title.isEmpty()) {
                 Toast.makeText(this, "Please fill Name", Toast.LENGTH_SHORT).show()

            }

            else if ( description.isEmpty()) {
                Toast.makeText(this, "Plese anter Description", Toast.LENGTH_SHORT).show()
            }

            else if (task== "Select Task Type") {
                Toast.makeText(this, "Please fill Gender", Toast.LENGTH_SHORT).show()
            }

            else{
                Toast.makeText(this, "Data Saved", Toast.LENGTH_SHORT).show()
                val note = Note(0, title, description, task)
                db.insertNote(note)
                finish()
            }


        }
    }
}
