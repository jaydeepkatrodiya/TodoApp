package com.example.todoapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.ImageView

class SplacwScreen : AppCompatActivity() {
    val TIMEOUTSCREEN = 2000
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splacw_screen)


        Handler().postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
        },TIMEOUTSCREEN.toLong())
    }
}